class FriendProfileModel {}
