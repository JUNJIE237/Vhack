import 'package:get/get.dart';
import 'listlanguage_item_model.dart';

class CaloriesAchivementWeeklyTwoModel {
  RxList<ListlanguageItemModel> listlanguageItemList =
      RxList.generate(2, (index) => ListlanguageItemModel());
}
