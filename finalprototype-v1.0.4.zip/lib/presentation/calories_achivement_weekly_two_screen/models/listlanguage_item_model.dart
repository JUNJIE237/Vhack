import 'package:get/get.dart';

class ListlanguageItemModel {
  Rx<String> languageTxt = Rx("msg_average_heart_beat".tr);

  Rx<String> oneHundredFortyTxt = Rx("lbl_140".tr);

  Rx<String> bpmTxt = Rx("lbl_bpm".tr);

  String? id = "";
}
