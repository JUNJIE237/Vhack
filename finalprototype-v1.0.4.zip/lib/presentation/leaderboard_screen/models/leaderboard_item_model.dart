import 'package:get/get.dart';

class LeaderboardItemModel {
  Rx<String> fiveTxt = Rx("lbl_5".tr);

  Rx<String> superheroTxt = Rx("lbl_superhero".tr);

  Rx<String> k750kcalTxt = Rx("lbl_750kcal".tr);

  String? id = "";
}
