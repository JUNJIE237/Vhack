import 'package:finalprototype/core/app_export.dart';
import 'package:finalprototype/presentation/add_friend_screen/models/add_friend_model.dart';

class AddFriendController extends GetxController {
  Rx<AddFriendModel> addFriendModelObj = AddFriendModel().obs;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }
}
