import 'package:finalprototype/core/app_export.dart';
import 'package:finalprototype/presentation/voucher_screen/models/voucher_model.dart';

class VoucherController extends GetxController {
  Rx<VoucherModel> voucherModelObj = VoucherModel().obs;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }
}
