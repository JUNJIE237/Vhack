import 'package:get/get.dart';

class DailyActivityItemModel {
  Rx<String> complete500kcalOneTxt = Rx("msg_complete_500_kcal".tr);

  Rx<String> group2386Txt = Rx("msg_500_kcal_500kcal".tr);

  Rx<String> oneTxt = Rx("lbl_1".tr);

  String? id = "";
}
