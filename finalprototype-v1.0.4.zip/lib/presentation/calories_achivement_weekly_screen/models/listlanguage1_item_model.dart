import 'package:get/get.dart';

class Listlanguage1ItemModel {
  Rx<String> languageTxt = Rx("msg_average_heart_beat".tr);

  Rx<String> oneHundredFortyTxt = Rx("lbl_140".tr);

  Rx<String> bpmTxt = Rx("lbl_bpm".tr);

  Rx<String> languageOneTxt = Rx("msg_total_exercising".tr);

  Rx<String> zipcodeTxt = Rx("lbl_50200".tr);

  Rx<String> minutesTxt = Rx("lbl_minutes".tr);

  String? id = "";
}
