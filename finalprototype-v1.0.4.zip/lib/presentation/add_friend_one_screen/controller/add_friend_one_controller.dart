import 'package:finalprototype/core/app_export.dart';
import 'package:finalprototype/presentation/add_friend_one_screen/models/add_friend_one_model.dart';

class AddFriendOneController extends GetxController {
  Rx<AddFriendOneModel> addFriendOneModelObj = AddFriendOneModel().obs;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }
}
