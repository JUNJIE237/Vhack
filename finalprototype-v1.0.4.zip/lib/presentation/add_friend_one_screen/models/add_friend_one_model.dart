class AddFriendOneModel {}
