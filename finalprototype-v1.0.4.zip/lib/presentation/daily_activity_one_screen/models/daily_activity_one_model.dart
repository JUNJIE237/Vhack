class DailyActivityOneModel {}
