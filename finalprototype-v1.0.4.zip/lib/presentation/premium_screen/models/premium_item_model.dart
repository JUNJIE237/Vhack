import 'package:get/get.dart';

class PremiumItemModel {
  Rx<String> languageTxt = Rx("msg_calories_consumed".tr);

  Rx<String> kcalCounterTxt = Rx("lbl_876_kcal".tr);

  String? id = "";
}
