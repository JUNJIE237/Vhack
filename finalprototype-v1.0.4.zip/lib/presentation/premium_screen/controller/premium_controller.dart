import 'package:finalprototype/core/app_export.dart';
import 'package:finalprototype/presentation/premium_screen/models/premium_model.dart';

class PremiumController extends GetxController {
  Rx<PremiumModel> premiumModelObj = PremiumModel().obs;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }
}
