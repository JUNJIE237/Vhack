class CaloriesAchivementWeeklyOneModel {}
