import 'package:finalprototype/core/app_export.dart';

class ApiClient extends GetConnect {}
